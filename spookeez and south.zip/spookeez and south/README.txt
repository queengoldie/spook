Hello seems you are a editor right? i will let you read. drag the data and images
 play fnf, go start playing spookeez and south, press 7 now working on progress.
when you're done, send me on YT (Queen! Goldie) in the comments. good luck!